function run ( message, bot, ds ) {
  if ( message.author.tag == bot.user.tag )
    message.delete ( )
  var e = new ds.MessageEmbed ( )
    .setDescription ( "E" )
  message.channel.send ( e ).then ( msg => msg.suppressEmbeds ( true ))
}

module.exports = run
module.exports.dependencies = [ "message", "bot", "ds" ]
