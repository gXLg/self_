const functions = require ( "../../functions.js" )

function run ( ) {
  functions.status_on ( )
}

module.exports = run
module.exports.dependencies = [ ]
