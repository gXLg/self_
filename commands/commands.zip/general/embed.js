const functions = require ( "../../functions.js" )

function run ( message, bot, ds, txt ) {
  if ( message.author.tag == bot.user.tag )
    message.delete ( )
  var e = new ds.MessageEmbed ( )
    .setColor ( functions.check_color ( color, message ))
    .setDescription ( txt )
  message.channel.send ( e )
}

module.exports = run
module.exports.dependencies = [ "message", "bot", "ds", "txt" ]
