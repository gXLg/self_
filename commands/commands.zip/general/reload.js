function run ( message ) {
  message.channel.send ( functions.lang.modules.reloaded )
}

module.exports = run
module.exports.dependencies = [ "message", "commands = get_commands ( )" ]
