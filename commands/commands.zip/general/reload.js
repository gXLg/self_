function run ( message ) {
  message.channel.send ( "Reloaded" )
}

module.exports = run
module.exports.dependencies = [ "message", "commands = get_commands ( )" ]
