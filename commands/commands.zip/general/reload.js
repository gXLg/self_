function run ( ) { }

module.exports = run
module.exports.dependencies = [ "commands = get_commands ( )" ]
