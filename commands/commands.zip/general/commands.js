const functions = require ( "../../functions.js" )

function run ( message, ds, bot, args, auth, commands ) {
  var e = new ds.MessageEmbed ( )
    .setColor ( functions.check_color ( color, message ))
    .setThumbnail ( `https://cdn.discordapp.com/app-assets/${auth.activity.appid}/${auth.assets.largeimage}.png` )
  if ( args [ 0 ])
    args.forEach ( a => e.addField ( a, commands [ a ].join ( ", " ) + "\u200b", true ))
  else
    for ( var c in commands )
      e.addField ( c + " (" + commands [ c ].length + ")", "\u200b", true )
  message.channel.send ( e )
}

module.exports = run
module.exports.dependencies = [ "message", "ds", "bot", "args", "auth", "commands" ]
