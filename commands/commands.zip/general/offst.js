const functions = require ( "../../functions.js" )

function run ( ) {
  functions.status_off ( )
}

module.exports = run
module.exports.dependencies = [ ]
