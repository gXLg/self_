const functions = require ( "../../functions.js" )

function run ( bot, txt ) {
  bot.users.fetch ( txt )
    .then ( ch => ch.send ( "." )
    .then ( msg => {
      msg.delete ( )
      functions.log ( functions.lang.modules.subto + ch.tag )
    }))
}

module.exports = run
module.exports.dependencies = [ "bot", "txt" ]
