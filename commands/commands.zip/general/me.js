const ms = require ( "pretty-ms" )
const config = require ( "../../config.json" )
const { version : ds_version } = require ( config.lib )

const functions = require ( "../../functions.js" )

function run ( message, ds, bot, args, auth ) {
  var e = new ds.MessageEmbed ( )
    .setColor ( functions.check_color ( color, message ))
    .setThumbnail ( `https://cdn.discordapp.com/app-assets/${auth.activity.appid}/${auth.assets.largeimage}.png` )
  var stats = { }
  stats [ functions.lang.modules.statuptime ] = `${ ms ( bot.uptime )}`
  stats [ functions.lang.modules.statload ] = `${( process.memoryUsage ( ).rss / 1024 / 1024).toFixed ( 2 )} MB RSS\n ${ ( process.memoryUsage ( ).heapUsed / 1024 / 1024 ).toFixed ( 2 )} MB Heap`
  stats [ functions.lang.modules.statping ] = `${ bot.ws.ping } ms`
  stats [ functions.lang.modules.statnodejs ] = `${ process.version } ` + functions.lang.modules.staton + ` ${ process.platform } ${ process.arch }`
  stats [ functions.lang.modules.statdiscordjs ] = `${ ds_version }`
  stats [ functions.lang.modules.statsource ] = "[GitHub](https://github.com/gXLg/self_)"
  if ( args [ 0 ])
    args.forEach ( a => e.addField ( a, stats [ a ], true ))
  else
    for ( var s in stats )
      e.addField ( s, stats [ s ], true )
  message.channel.send ( e )
}

module.exports = run
module.exports.dependencies = [ "message", "ds", "bot", "args", "auth" ]
