const joker = require ( "one-liner-joke" )

const functions = require ( "../../functions.js" )

function run ( message ) {
  var joke = joker.getRandomJoke ( )
  message.channel.send ( joke.body )
}

module.exports = run
module.exports.dependencies = [ "message" ]
