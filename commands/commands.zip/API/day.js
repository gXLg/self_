const unfurled = require ( "unfurled" )

const functions = require ( "../../functions.js" )

function run ( message, ds ) {
  unfurled ( "https://nationaltoday.com" ).then ( data => {
    var text = data.other.description.split ( "." ) [ 0 ].split ( " - " )
    var e = new ds.MessageEmbed ( )
      .setColor ( functions.check_color ( color, message ))
      .setTitle ( text [ 0 ])
      .setURL ( "https://nationaltoday.com/" )
      .setDescription ( text [ 1 ])
    message.channel.send ( e )
   })
}

module.exports = run
module.exports.dependencies = [ "message", "ds" ]
