const yt = require ( "youtube-random-video" )
const decode = require ( "html-entities" ).decode


const functions = require ( "../../functions.js" )

function run ( message, ds, ytapi ) {
  yt.getRandomVid ( ytapi, ( err, data ) => {
    var e = new ds.MessageEmbed ( )
      .setColor ( functions.check_color ( color, message ))
      .setTitle ( decode ( data.snippet.title ))
      .setURL ( "https://youtu.be/" + data.id.videoId )
      .setDescription ( decode ( data.snippet.description ))
      .setFooter ( decode ( data.snippet.channelTitle ))
    message.channel.send ( e )
  })
}

module.exports = run
module.exports.dependencies = [ "message", "ds", "auth.user.ytapi" ]
